Build project:
    todo: in project root dir call "make"
    result: lexer binary file would be created

Run program:
    {path_to_proj}/parser